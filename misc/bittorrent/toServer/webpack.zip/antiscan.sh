#!/bin/bash
# If the server return 403 error etc, this limitation won't work well because the tcp connections close too fast
iptables -A INPUT -p tcp --dport 6969 -m state --state NEW -m recent --set
iptables -A INPUT -p tcp --dport 6969 -m state --state NEW -m recent --update --seconds 8 --hitcount 4 -j DROP